default_app_config = 'blog.apps.BlogConfig'  # Update with your app name

